import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import { doc, getFirestore, serverTimestamp, setDoc } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

const firebaseConfig = window.LUCKY_GARAGE_FIREBASE_CONFIG || {};
const config = window.YU_STORE_CONFIG || {};
const db = getFirestore(initializeApp(firebaseConfig));
const $ = (selector) => document.querySelector(selector);
const money = (value) => `NT$${Math.max(0, Number(value) || 0).toLocaleString("zh-TW")}`;
let captcha = 0;

function cleanPhone(value) {
  let digits = String(value || "").replace(/\D/g, "");
  if (digits.startsWith("886")) digits = `0${digits.slice(3)}`;
  return digits;
}
function makeId() {
  const date = new Date();
  const ymd = `${date.getFullYear()}${String(date.getMonth()+1).padStart(2,"0")}${String(date.getDate()).padStart(2,"0")}`;
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint32Array(4);
  crypto.getRandomValues(bytes);
  return `PLATE-${ymd}-${[...bytes].map(value => chars[value % chars.length]).join("")}`;
}
function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove("show"), 3200);
}
function lineChatUrl() {
  return config.lineUrl || "https://line.me/R/ti/p/%40762eqvlg";
}
function compactPlateLineMessage({ orderId, plateType, plateNumber, customerName, phone }) {
  return `官網訂製 ${orderId}\n${plateType}｜${plateNumber}\n${customerName} ${phone}\n請協助確認付款。`;
}
let latestPlateFullMessage = "";
function showOrderSuccess(orderId, lineUrl, fullMessage, prefillMessage, duplicate = false) {
  const screen = $("#orderSuccessScreen");
  if (!screen) return;
  latestPlateFullMessage = String(fullMessage || prefillMessage || "");
  $("#orderSuccessTitle").textContent = duplicate ? "已沿用上一筆訂製需求" : "訂製需求已建立";
  $("#orderSuccessText").textContent = duplicate
    ? "短時間內相同資料不重複建單。請按下方「複製訂單並開啟 LINE」。系統會先複製完整訂單，再開啟官方 LINE；進入聊天室後長按輸入框貼上即可。"
    : "資料已送進小宇微電訂單系統。請按下方「複製訂單並開啟 LINE」。系統會先複製完整訂單，再開啟官方 LINE；進入聊天室後長按輸入框貼上即可。";
  $("#orderSuccessId").textContent = orderId;
  const preview = $("#orderSuccessPreview");
  if (preview) preview.textContent = latestPlateFullMessage;
  $("#orderSuccessLine").href = lineUrl || (config.lineUrl || "https://line.me/R/ti/p/%40762eqvlg");
  screen.classList.add("show");
  screen.setAttribute("aria-hidden", "false");
}
function newCaptcha() {
  const a = Math.floor(Math.random()*8)+2;
  const b = Math.floor(Math.random()*8)+2;
  captcha = a+b;
  $("#captchaQuestion").textContent = `人類驗證：${a} + ${b} = ?`;
  $("#captchaAnswer").value = "";
}

const price = Number(config.platePrice || 9500);
const deposit = Number(config.plateDeposit || 5500);
const balance = Number(config.plateBalance || 4000);
$("#priceText").textContent = money(price);
$("#depositText").textContent = money(deposit);
$("#balanceText").textContent = money(balance);

$("#plateNumber").addEventListener("input", () => {
  const value = $("#plateNumber").value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0,12);
  $("#plateNumber").value = value;
  $("#platePreview").textContent = value || "ABC-1234";
});

const PLATE_DUPLICATE_WINDOW_MS = 5 * 60 * 1000;
function plateFingerprint({ plateType, plateNumber, phone, address }) {
  return [plateType, plateNumber, phone, address].map((value) => String(value || "").trim().toLowerCase()).join("|");
}
function recentPlateSubmission(fingerprint) {
  try {
    const item = JSON.parse(sessionStorage.getItem("YU_RECENT_PLATE_ORDER") || "null");
    if (!item || item.fingerprint !== fingerprint || !item.orderId || !item.message) return null;
    if (Date.now() - Number(item.time || 0) > PLATE_DUPLICATE_WINDOW_MS) return null;
    return item;
  } catch { return null; }
}
function rememberPlateSubmission(payload) {
  try { sessionStorage.setItem("YU_RECENT_PLATE_ORDER", JSON.stringify({ ...payload, time:Date.now() })); } catch {}
}

$("#plateForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if ($("#website").value) return;
  if (Number($("#captchaAnswer").value) !== captcha) { newCaptcha(); toast("驗證答案錯誤，請重新計算。"); return; }

  const customerName = $("#name").value.trim();
  const phone = cleanPhone($("#phone").value);
  const address = $("#address").value.trim();
  const plateNumber = $("#plateNumber").value.trim().toUpperCase();
  const plateType = $("#plateType").value;
  if (!customerName || phone.length < 9 || address.length < 3 || !plateNumber) { toast("請完整填寫訂製資料。"); return; }

  const fingerprint = plateFingerprint({ plateType, plateNumber, phone, address });
  const recent = recentPlateSubmission(fingerprint);
  if (recent) {
    const recentPrefill = recent.prefillMessage || recent.message;
    const recentLineUrl = lineChatUrl();
    toast(`已沿用訂製需求 ${recent.orderId}，避免重複建立。`);
    showOrderSuccess(recent.orderId, recentLineUrl, recent.message, recentPrefill, true);
    return;
  }

  const orderId = makeId();
  const data = {
    orderNo:orderId, orderId, source:"official-store-plate", customerName, custName:customerName, phone, custPhone:phone, address, custAddress:address,
    model:"紀念展示車牌", itemName:`${plateType}｜${plateNumber}`, color:"依訂製樣式", vehicleVariant:plateType, battery:"不適用", price, totalAmount:money(price),
    cost:0, netProfit:price, deposit:0, balancePaid:0, licenseMode:"自行辦理", deliveryMode:"物流寄送", paymentMethod:"轉帳",
    paymentTerms:`訂金 ${money(deposit)}／尾款 ${money(balance)}（貨到付款）`, status:"待訂金", deliveredAt:"",
    notes:`訂製號碼：${plateNumber}。僅供紀念展示，不可上路使用。`, createdAt:serverTimestamp(), updatedAt:serverTimestamp(), timestamp:serverTimestamp(), createdBy:"public-store", updatedBy:"public-store"
  };

  const button = $("#submitBtn");
  button.disabled = true;
  button.textContent = "送出中…";
  try {
    await setDoc(doc(db, "orders", orderId), data);
    const message = `您好小宇，我要訂製紀念展示牌：\n訂單編號：${orderId}\n類型：${plateType}\n號碼：${plateNumber}\n姓名：${customerName}\n電話：${phone}\n收件資料：${address}\n付款方式：訂金 ${money(deposit)}／尾款 ${money(balance)}（貨到付款）\n請協助確認付款。`;
    const prefillMessage = compactPlateLineMessage({ orderId, plateType, plateNumber, customerName, phone });
    const targetLineUrl = lineChatUrl();
    try { await navigator.clipboard.writeText(message); } catch {}
    rememberPlateSubmission({ fingerprint, orderId, message, prefillMessage });
    toast(`訂製需求 ${orderId} 已建立。`);
    showOrderSuccess(orderId, targetLineUrl, message, prefillMessage);
    event.target.reset();
    $("#plateNumber").value = "ABC-1234";
    $("#platePreview").textContent = "ABC-1234";
    newCaptcha();
  } catch (error) {
    console.error(error);
    toast("送出失敗，請直接聯絡官方 LINE。");
  } finally {
    button.disabled = false;
    button.textContent = "送出訂製需求";
  }
});

const successLineButton = $("#orderSuccessLine");
if (successLineButton) {
  successLineButton.addEventListener("click", async (event) => {
    event.preventDefault();
    const href = lineChatUrl();
    let copied = false;
    try {
      if (latestPlateFullMessage) {
        await navigator.clipboard.writeText(latestPlateFullMessage);
        copied = true;
      }
    } catch (error) { console.warn("clipboard copy failed", error); }
    if (copied) toast("完整訂製內容已複製，正在開啟 LINE；到聊天室長按貼上即可。");
    else toast("瀏覽器未允許自動複製，請先按下方「複製完整訂單」再開 LINE。");
    window.setTimeout(() => { window.location.href = href; }, copied ? 180 : 900);
  });
}
const successCopyButton = $("#orderSuccessCopy");
if (successCopyButton) {
  successCopyButton.addEventListener("click", async () => {
    if (!latestPlateFullMessage) return;
    try {
      await navigator.clipboard.writeText(latestPlateFullMessage);
      toast("完整訂製內容已複製，回 LINE 長按貼上即可。");
    } catch {
      toast("瀏覽器未允許自動複製，請長按上方內容複製。");
    }
  });
}

newCaptcha();
