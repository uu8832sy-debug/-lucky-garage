import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signInWithRedirect,
  signOut
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-auth.js";
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";
import {
  deleteObject,
  getDownloadURL,
  getStorage,
  ref,
  uploadBytes
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-storage.js";

const OWNER_EMAIL = "uu8832sr@gmail.com";
const firebaseConfig = window.LUCKY_GARAGE_FIREBASE_CONFIG || {};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const DEFAULT_PRODUCTS = (Array.isArray(window.YU_PRODUCT_CATALOG) ? window.YU_PRODUCT_CATALOG : []).map((product) => ({
  ...structuredClone(product),
  images: (Array.isArray(product.images) ? product.images : []).map((image, index) => (
    typeof image === "string"
      ? { url:image, path:"", isPrimary:index === 0, static:true }
      : { ...image, isPrimary:image?.isPrimary === true || index === 0 }
  ))
}));

let currentUser = null;
let products = [];
let orders = [];
let editingProductId = null;
let creatingProduct = false;
let storedProductIds = new Set();

function normalizeEmail(value) { return String(value || "").trim().toLowerCase(); }
function money(value) { return `NT$${Math.max(0, Number(value) || 0).toLocaleString("zh-TW")}`; }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>'"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c])); }
function timestampMillis(value) {
  if (typeof value?.toMillis === "function") return value.toMillis();
  if (value?.seconds) return value.seconds * 1000;
  const parsed = Date.parse(value || "");
  return Number.isNaN(parsed) ? 0 : parsed;
}
function formatDate(value) {
  const ms = timestampMillis(value);
  return ms ? new Intl.DateTimeFormat("zh-TW", { dateStyle:"short", timeStyle:"short" }).format(new Date(ms)) : "—";
}
function showToast(message) {
  $("#toastMsg").textContent = message;
  const t = $("#toast");
  t.classList.remove("translate-y-20", "opacity-0");
  setTimeout(() => t.classList.add("translate-y-20", "opacity-0"), 2600);
}

async function isAdminUser(user) {
  if (!user || user.isAnonymous) return false;
  if (user.emailVerified && normalizeEmail(user.email) === OWNER_EMAIL) return true;
  try {
    const snap = await getDoc(doc(db, "admins", user.uid));
    return snap.exists() && snap.data().enabled === true;
  } catch {
    return false;
  }
}
async function beginLogin() {
  $("#loginMessage").textContent = "正在開啟 Google 登入…";
  $("#loginBtn").disabled = true;
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt:"select_account" });
    await signInWithPopup(auth, provider);
  } catch (error) {
    const code = String(error?.code || "");
    if (code.includes("popup-blocked") || code.includes("operation-not-supported")) {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt:"select_account" });
      await signInWithRedirect(auth, provider);
      return;
    }
    $("#loginMessage").textContent = error?.message || "登入失敗。";
  } finally {
    $("#loginBtn").disabled = false;
  }
}
function showLoggedOut() {
  currentUser = null;
  $("#loginCard").classList.remove("hidden");
  $("#deniedCard").classList.add("hidden");
  $("#adminApp").classList.add("hidden");
  $("#headerActions").classList.add("hidden");
  $("#headerActions").classList.remove("flex");
}
function showDenied(user) {
  currentUser = user;
  $("#loginCard").classList.add("hidden");
  $("#deniedCard").classList.remove("hidden");
  $("#adminApp").classList.add("hidden");
  $("#deniedMessage").textContent = `目前登入：${user.email || user.uid}`;
}
async function showAdmin(user) {
  currentUser = user;
  $("#loginCard").classList.add("hidden");
  $("#deniedCard").classList.add("hidden");
  $("#adminApp").classList.remove("hidden");
  $("#headerActions").classList.remove("hidden");
  $("#headerActions").classList.add("flex");
  $("#adminIdentity").textContent = user.email || user.uid;
  await Promise.all([loadOrders(), loadProducts()]);
}

function normalizeOrder(item) {
  const data = item.data();
  return {
    id:item.id,
    orderNo:data.orderNo || data.orderId || item.id,
    customerName:data.customerName || data.custName || "未命名",
    phone:data.phone || data.custPhone || "—",
    address:data.address || data.custAddress || "—",
    model:data.model || data.itemName || "—",
    variant:data.vehicleVariant || data.battery || "",
    price:Number(String(data.totalAmount || "").replace(/\D/g, "")) || Number(data.price || 0) || 0,
    status:data.status || "待訂金",
    createdAt:data.createdAt || data.timestamp || "",
    raw:data
  };
}
function isWebsiteCheckoutOrder(order) {
  const data = order?.raw || {};
  const source = String(data.source || "").trim();
  const createdBy = String(data.createdBy || "").trim();
  // 官網前台訂單固定由 public-store 建立，歷史手動訂單不會混入。
  return source.startsWith("official-store") && createdBy === "public-store";
}
async function loadOrders() {
  const tbody = $("#adminOrderTableBody");
  tbody.innerHTML = '<tr><td colspan="7" class="p-5 text-center text-slate-500">讀取訂單中…</td></tr>';
  try {
    const snap = await getDocs(collection(db, "orders"));
    orders = snap.docs
      .map(normalizeOrder)
      .filter(isWebsiteCheckoutOrder)
      .sort((a,b) => timestampMillis(b.createdAt) - timestampMillis(a.createdAt));
    renderOrders();
  } catch (error) {
    console.error(error);
    tbody.innerHTML = `<tr><td colspan="8" class="p-5 text-center text-rose-400">載入失敗：${escapeHtml(error?.message || "請檢查規則")}</td></tr>`;
  }
}
function renderOrders() {
  const keyword = $("#orderSearch").value.trim().toLowerCase();
  const list = orders.filter((o) => [o.orderNo,o.customerName,o.phone,o.address,o.model].join(" ").toLowerCase().includes(keyword));
  const tbody = $("#adminOrderTableBody");
  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="p-5 text-center text-slate-500">目前沒有官網前台送出的訂單</td></tr>';
    return;
  }
  const statuses = ["待訂金","已付訂金","備車中","待交車","已交車","取消"];
  tbody.innerHTML = list.map((o) => `<tr class="hover:bg-slate-900/50">
    <td class="p-3 text-emerald-400 font-bold">${escapeHtml(o.orderNo)}</td>
    <td class="p-3"><strong class="text-white block">${escapeHtml(o.customerName)}</strong><small class="text-slate-500">${escapeHtml(o.phone)}</small></td>
    <td class="p-3"><strong class="block">${escapeHtml(o.model)}</strong><small class="text-slate-500">${escapeHtml(o.variant)}</small></td>
    <td class="p-3 max-w-56">${escapeHtml(o.address)}</td>
    <td class="p-3 font-bold">${money(o.price)}</td>
    <td class="p-3"><select class="order-status bg-slate-950 border border-slate-700 rounded-lg p-2" data-order-id="${escapeHtml(o.id)}">${statuses.map((s) => `<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select></td>
    <td class="p-3 text-slate-500">${formatDate(o.createdAt)}</td>
  </tr>`).join("");
  $$(".order-status").forEach((select) => select.addEventListener("change", async () => {
    select.disabled = true;
    try {
      await updateDoc(doc(db,"orders",select.dataset.orderId), { status:select.value, updatedAt:serverTimestamp(), updatedBy:currentUser.uid });
      const found = orders.find((o) => o.id === select.dataset.orderId);
      if (found) found.status = select.value;
      showToast("訂單狀態已更新");
    } catch (error) {
      console.error(error); showToast("狀態更新失敗");
    } finally { select.disabled = false; }
  }));
}

async function loadProducts() {
  const tbody = $("#adminProductTableBody");
  tbody.innerHTML = '<tr><td colspan="8" class="p-5 text-center text-slate-500">讀取商品中…</td></tr>';
  try {
    const snap = await getDocs(collection(db,"products"));
    const remote = snap.docs.map((item) => ({ id:item.id, ...item.data() }));
    storedProductIds = new Set(remote.map((item) => item.id));
    const remoteMap = new Map(remote.map((item) => [item.id, item]));
    products = DEFAULT_PRODUCTS.map((item) => {
      const remoteItem = remoteMap.get(item.id) || {};
      const remoteImages = Array.isArray(remoteItem.images) ? remoteItem.images : [];
      return {
        ...item,
        ...remoteItem,
        images: (remoteImages.length ? remoteImages : item.images).map((image, index) => (
          typeof image === "string"
            ? { url:image, path:"", isPrimary:index === 0, static:true }
            : { ...image, isPrimary:image?.isPrimary === true || (!remoteImages.some((candidate) => candidate?.isPrimary) && index === 0) }
        ))
      };
    });
    for (const item of remote) {
      if (!products.some((product) => product.id === item.id)) {
        products.push({
          ...item,
          images:(Array.isArray(item.images) ? item.images : []).map((image,index) => typeof image === "string" ? {url:image,path:"",isPrimary:index===0,static:true} : image)
        });
      }
    }
    products.sort((a,b) => Number(a.order||999)-Number(b.order||999));
    renderProducts();
  } catch (error) {
    console.error(error);
    tbody.innerHTML = `<tr><td colspan="8" class="p-5 text-center text-rose-400">載入失敗：${escapeHtml(error?.message || "請檢查規則")}</td></tr>`;
  }
}
function renderProducts() {
  const tbody = $("#adminProductTableBody");
  if (!products.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="p-5 text-center text-slate-500">尚未建立商品，請按「補齊預設商品」或「新增商品」。</td></tr>';
    return;
  }
  tbody.innerHTML = products.map((p) => `<tr class="hover:bg-slate-900/50"><td class="p-3 text-slate-400">${Number(p.order||0)}</td><td class="p-3 text-emerald-400">${Array.isArray(p.images)?p.images.length:0} 張</td><td class="p-3 font-bold text-white">${escapeHtml(p.name)}</td><td class="p-3 text-slate-400">${escapeHtml(p.style||"")}</td><td class="p-3">${money(p.priceLead)}</td><td class="p-3">${Number(p.priceLithium||0)>0?money(p.priceLithium):"不提供"}</td><td class="p-3">${p.visible===false?'<span class="text-rose-400">隱藏</span>':'<span class="text-emerald-400">顯示</span>'}</td><td class="p-3 text-right"><button class="edit-product bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-2 rounded-lg font-bold" data-product-id="${escapeHtml(p.id)}">編輯</button></td></tr>`).join("");
  $$(".edit-product").forEach((button) => button.addEventListener("click", () => openProductModal(button.dataset.productId)));
}
async function seedProducts() {
  const batch = writeBatch(db);
  const existing = storedProductIds;
  let count = 0;
  for (const product of DEFAULT_PRODUCTS) {
    if (!existing.has(product.id)) {
      batch.set(doc(db,"products",product.id), { ...product, createdAt:serverTimestamp(), updatedAt:serverTimestamp(), updatedBy:currentUser.uid });
      count += 1;
    }
  }
  if (!count) return showToast("12 款商品已經齊全");
  await batch.commit();
  showToast(`已補齊 ${count} 款商品`);
  await loadProducts();
}
function openProductModal(productId) {
  creatingProduct = false;
  editingProductId = productId;
  const p = products.find((item) => item.id === productId);
  if (!p) return;
  $("#editModalProductTitle").textContent = `編輯 ${p.name}（${p.style || ""}）`;
  $("#editProductIdInput").value = p.id || "";
  $("#editOrderInput").value = Number(p.order || 999);
  $("#editNameInput").value = p.name || "";
  $("#editStyleInput").value = p.style || "";
  $("#editColorsInput").value = Array.isArray(p.colors) ? p.colors.join("、") : "";
  $("#editPriceLeadInput").value = Number(p.priceLead || 0);
  $("#editPriceLithiumInput").value = Number(p.priceLithium || 0) || "";
  $("#editRangeLeadInput").value = p.rangeLead || "";
  $("#editRangeLithiumInput").value = p.rangeLithium || "";
  $("#editLifeLeadInput").value = p.lifeLead || "約 2 年";
  $("#editLifeLithiumInput").value = p.lifeLithium || (Number(p.priceLithium||0)>0 ? "約 8–10 年" : "");
  $("#editDescriptionInput").value = p.description || "";
  $("#editFeaturesInput").value = Array.isArray(p.features) ? p.features.join("\n") : "";
  $("#editNoteInput").value = p.note || "";
  $("#editVisibleInput").checked = p.visible !== false;
  renderGallery(p);
  const modal = $("#editProductModal");
  modal.classList.remove("hidden"); modal.classList.add("flex");
}
function newProduct() {
  creatingProduct = true;
  editingProductId = `custom-${Date.now()}`;
  const nextOrder = products.reduce((max,p)=>Math.max(max,Number(p.order||0)),0)+1;
  const p = { id:editingProductId, order:nextOrder, name:"", style:"", colors:[], priceLead:0, priceLithium:null, rangeLead:"", rangeLithium:"", lifeLead:"約 2 年", lifeLithium:"", description:"", features:[], note:"", visible:true, images:[] };
  products.push(p);
  $("#editModalProductTitle").textContent = "新增商品";
  $("#editProductIdInput").value = p.id;
  $("#editOrderInput").value = p.order;
  $("#editNameInput").value = "";
  $("#editStyleInput").value = "";
  $("#editColorsInput").value = "";
  $("#editPriceLeadInput").value = "";
  $("#editPriceLithiumInput").value = "";
  $("#editRangeLeadInput").value = "";
  $("#editRangeLithiumInput").value = "";
  $("#editLifeLeadInput").value = "約 2 年";
  $("#editLifeLithiumInput").value = "";
  $("#editDescriptionInput").value = "";
  $("#editFeaturesInput").value = "";
  $("#editNoteInput").value = "";
  $("#editVisibleInput").checked = true;
  renderGallery(p);
  const modal = $("#editProductModal");
  modal.classList.remove("hidden"); modal.classList.add("flex");
}

function closeProductModal() {
  const modal = $("#editProductModal");
  modal.classList.add("hidden"); modal.classList.remove("flex");
  if (creatingProduct && editingProductId && !storedProductIds.has(editingProductId)) {
    products = products.filter((p) => p.id !== editingProductId);
    renderProducts();
  }
  editingProductId = null;
  creatingProduct = false;
}
function renderGallery(product) {
  const images = Array.isArray(product.images) ? product.images : [];
  const grid = $("#productGalleryGrid");
  if (!images.length) { grid.innerHTML = '<div class="col-span-full text-slate-500 text-center py-4">尚無圖片</div>'; return; }
  grid.innerHTML = images.map((img,i) => `<div class="relative rounded-xl overflow-hidden border ${img.isPrimary?'border-emerald-500':'border-slate-800'}"><img src="${escapeHtml(typeof img === "string" ? img : img.url)}" alt="${escapeHtml(product.name)} 圖片 ${i+1}" class="w-full h-24 object-cover" loading="lazy" /><div class="absolute inset-x-0 bottom-0 bg-slate-950/90 p-1 flex gap-1 justify-center">${img.isPrimary?'<span class="text-[9px] text-emerald-400 px-1">主圖</span>':`<button class="set-primary bg-emerald-500 text-slate-950 px-1.5 rounded text-[9px]" data-index="${i}">設主圖</button>`}<button class="delete-image bg-rose-500 text-white px-1.5 rounded text-[9px]" data-index="${i}">刪除</button></div></div>`).join("");
  $$(".set-primary").forEach((button) => button.addEventListener("click", () => setPrimaryImage(Number(button.dataset.index))));
  $$(".delete-image").forEach((button) => button.addEventListener("click", () => deleteImage(Number(button.dataset.index))));
}
async function compressImageForFirestore(file) {
  const bitmap = await createImageBitmap(file);
  const maxSide = 1000;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d", { alpha:false });
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  if (typeof bitmap.close === "function") bitmap.close();
  let quality = .78;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 190000 && quality > .40) {
    quality -= .08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 230000) throw new Error("照片壓縮後仍過大，請換一張或先裁切。");
  return dataUrl;
}
async function saveEmbeddedImage(product, file) {
  const embeddedCount = (product.images || []).filter((img) => img?.embedded).length;
  if (embeddedCount >= 3) throw new Error("未啟用 Storage 時，每台車最多直接存 3 張自訂照片；請先刪除舊自訂圖再上傳。");
  const dataUrl = await compressImageForFirestore(file);
  product.images.push({ url:dataUrl, path:"", isPrimary:product.images.length===0, embedded:true });
}
async function uploadImages(files) {
  const product = products.find((p) => p.id === editingProductId);
  if (!product || !files.length) return;
  if (creatingProduct && !storedProductIds.has(product.id)) {
    showToast("請先儲存商品基本資料，再上傳圖片");
    return;
  }
  if (!Array.isArray(product.images)) product.images = [];
  for (let i=0;i<files.length;i+=1) {
    const file = files[i];
    $("#uploadProgressText").textContent = `處理 ${i+1}/${files.length}`;
    let uploaded = false;
    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
      const path = `products/${product.id}/${Date.now()}_${i}_${safeName}`;
      const objectRef = ref(storage,path);
      await uploadBytes(objectRef,file,{ contentType:file.type || "image/jpeg" });
      const url = await getDownloadURL(objectRef);
      product.images.push({ url, path, isPrimary:product.images.length===0 });
      uploaded = true;
    } catch (storageError) {
      console.warn("Storage unavailable, saving compressed image in Firestore", storageError);
    }
    if (!uploaded) await saveEmbeddedImage(product, file);
  }
  await setDoc(doc(db,"products",product.id), { images:product.images, updatedAt:serverTimestamp(), updatedBy:currentUser.uid }, { merge:true });
  $("#uploadProgressText").textContent = "上傳完成";
  renderGallery(product); renderProducts();
}
async function setPrimaryImage(index) {
  const product = products.find((p) => p.id === editingProductId);
  if (!product) return;
  product.images = (product.images || []).map((img,i) => ({...img,isPrimary:i===index}));
  await setDoc(doc(db,"products",product.id), { images:product.images, updatedAt:serverTimestamp(), updatedBy:currentUser.uid }, { merge:true });
  renderGallery(product); renderProducts();
}
async function deleteImage(index) {
  const product = products.find((p) => p.id === editingProductId);
  const image = product?.images?.[index];
  if (!product || !image || !confirm("確定從商品圖庫移除這張照片？")) return;
  if (image.path) { try { await deleteObject(ref(storage,image.path)); } catch (error) { console.warn(error); } }
  product.images.splice(index,1);
  if (product.images.length && !product.images.some((img) => img.isPrimary)) product.images[0].isPrimary = true;
  await setDoc(doc(db,"products",product.id), { images:product.images, updatedAt:serverTimestamp(), updatedBy:currentUser.uid }, { merge:true });
  renderGallery(product); renderProducts();
}
async function saveProduct() {
  const product = products.find((p) => p.id === editingProductId);
  if (!product) return;
  const name = $("#editNameInput").value.trim();
  if (!name) throw new Error("請填寫車款名稱");
  const colors = $("#editColorsInput").value.split(/[、,，]/).map((v) => v.trim()).filter(Boolean);
  const update = {
    order:Math.max(1,Number($("#editOrderInput").value)||999),
    name,
    style:$("#editStyleInput").value.trim(),
    colors,
    priceLead:Math.max(0,Number($("#editPriceLeadInput").value)||0),
    priceLithium:$("#editPriceLithiumInput").value===""?null:Math.max(0,Number($("#editPriceLithiumInput").value)||0),
    rangeLead:$("#editRangeLeadInput").value.trim(),
    rangeLithium:$("#editRangeLithiumInput").value.trim(),
    lifeLead:$("#editLifeLeadInput").value.trim() || "約 2 年",
    lifeLithium:$("#editLifeLithiumInput").value.trim(),
    description:$("#editDescriptionInput").value.trim(),
    features:$("#editFeaturesInput").value.split(/\n+/).map((v)=>v.trim()).filter(Boolean),
    note:$("#editNoteInput").value.trim(),
    visible:$("#editVisibleInput").checked,
    updatedAt:serverTimestamp(),
    updatedBy:currentUser.uid
  };
  const saveBtn = $("#saveProductBtn");
  saveBtn.disabled = true;
  const originalText = saveBtn.textContent;
  saveBtn.textContent = "儲存中…";
  try {
    await setDoc(doc(db,"products",product.id),update,{ merge:true });
    storedProductIds.add(product.id);
    Object.assign(product,update);
    products.sort((a,b)=>Number(a.order||999)-Number(b.order||999));
    creatingProduct = false;
    renderProducts(); closeProductModal(); showToast("商品已儲存，前台重新整理後同步更新");
  } catch (error) {
    console.error(error);
    const msg = String(error?.code || error?.message || "");
    if (msg.includes("permission-denied")) throw new Error("商品儲存被 Firebase 權限拒絕，請發布此版本附帶的 firestore.rules");
    throw error;
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = originalText;
  }
}

async function resetOrDeleteProduct() {
  const product = products.find((p)=>p.id===editingProductId);
  if (!product || !storedProductIds.has(product.id)) return showToast("此商品目前只有內建資料，沒有雲端覆蓋可刪除");
  const isDefault = DEFAULT_PRODUCTS.some((p)=>p.id===product.id);
  const message = isDefault ? "確定清除這台車的後台自訂內容並恢復網站內建預設？" : "確定永久刪除這個自訂商品？";
  if (!confirm(message)) return;
  await deleteDoc(doc(db,"products",product.id));
  closeProductModal();
  await loadProducts();
  showToast(isDefault ? "已恢復內建預設商品" : "自訂商品已刪除");
}
function switchTab(tab) {
  const view = tab === "products" ? "products" : "dashboard";
  document.querySelectorAll("[data-shell-panel]").forEach((panel) => {
    panel.hidden = panel.dataset.shellPanel !== view;
  });
  document.querySelectorAll("[data-shell-view]").forEach((button) => {
    button.classList.toggle("is-shell-active", button.dataset.shellView === view);
  });
  history.replaceState(null, "", `#${view}`);
}

$("#loginBtn").addEventListener("click",beginLogin);
$("#switchAccountBtn").addEventListener("click",async()=>{await signOut(auth);beginLogin();});
$("#logoutBtn").addEventListener("click",()=>signOut(auth));
$("#refreshOrdersBtn").addEventListener("click",loadOrders);
$("#orderSearch").addEventListener("input",renderOrders);
$("#refreshProductsBtn").addEventListener("click",loadProducts);
$("#addProductBtn").addEventListener("click",newProduct);
$("#seedProductsBtn").addEventListener("click",()=>seedProducts().catch((e)=>{console.error(e);showToast("建立商品失敗");}));
$$(".admin-tab").forEach((button)=>button.addEventListener("click",()=>switchTab(button.dataset.adminTab)));
$("#closeProductModalBtn").addEventListener("click",closeProductModal);
$("#chooseImagesBtn").addEventListener("click",()=>$("#imageFileInput").click());
$("#imageFileInput").addEventListener("change",(event)=>uploadImages([...event.target.files]).catch((e)=>{console.error(e);showToast("圖片上傳失敗，請確認 Storage 規則");}));
$("#saveProductBtn").addEventListener("click",()=>saveProduct().catch((e)=>{console.error(e);showToast(e?.message || "商品儲存失敗");}));
$("#deleteProductBtn").addEventListener("click",()=>resetOrDeleteProduct().catch((e)=>{console.error(e);showToast(e?.message || "操作失敗");}));

onAuthStateChanged(auth, async (user) => {
  if (!user) return showLoggedOut();
  if (!(await isAdminUser(user))) return showDenied(user);
  await showAdmin(user);
});
