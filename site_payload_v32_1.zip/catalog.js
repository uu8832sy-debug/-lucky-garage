/* 小宇微電E-BIKE｜公開商品目錄 v32.1 */
const YU_72V_BATTERY_SPECS = [
  { code:"7230", label:"72V30Ah 磷酸鋰鐵（抽取式）", battery:"72V30Ah 磷酸鋰鐵", range:"約 40～60 公里", life:"依電池保固約定", warning:"" },
  { code:"7250", label:"72V50Ah 三元鋰（抽取式）", battery:"72V50Ah 三元鋰", range:"約 65～100 公里", life:"依電池保固約定", warning:"" },
  { code:"7650", label:"76V50Ah 三元鋰（抽取式）", battery:"76V50Ah 三元鋰", range:"約 70～105 公里", life:"依電池保固約定", warning:"下單前須確認控制器相容" },
  { code:"7260", label:"72V60Ah 三元鋰（抽取式）", battery:"72V60Ah 三元鋰", range:"約 80～120 公里", life:"依電池保固約定", warning:"" },
  { code:"7660", label:"76V60Ah 三元鋰（抽取式）", battery:"76V60Ah 三元鋰", range:"約 85～125 公里", life:"依電池保固約定", warning:"下單前須確認控制器相容" },
  { code:"7265", label:"72V65Ah 三元鋰（抽取式）", battery:"72V65Ah 三元鋰", range:"約 85～130 公里", life:"依電池保固約定", warning:"下單前須確認電池箱空間" },
  { code:"7665", label:"76V65Ah 三元鋰（抽取式）", battery:"76V65Ah 三元鋰", range:"約 90～135 公里", life:"依電池保固約定", warning:"下單前須確認控制器與電池箱空間" },
  { code:"7275", label:"72V75Ah 三元鋰（抽取式）", battery:"72V75Ah 三元鋰", range:"約 100～150 公里", life:"依電池保固約定", warning:"下單前須確認電池箱空間" },
  { code:"7675", label:"76V75Ah 三元鋰（抽取式）", battery:"76V75Ah 三元鋰", range:"約 105～155 公里", life:"依電池保固約定", warning:"下單前須確認控制器與電池箱空間" }
];
function yu72BatteryOptions(prices) {
  return YU_72V_BATTERY_SPECS.map((item, index) => ({
    ...item,
    price:Number(prices[index] || 0),
    removable:true,
    publicOrder:["7230", "7250"].includes(item.code),
    leadTime:"約 20～30 天",
    depositRate:0.5
  }));
}
window.YU_PRODUCT_CATALOG = [
  {
    "id": "scooter-1",
    "order": 1,
    "name": "大偉士",
    "style": "頂規改裝版",
    "visible": true,
    "priceLead": 35000,
    "priceLithium": 49800,
    "batteryOptions": yu72BatteryOptions([49800, 58800, 59800, 61800, 62800, 63800, 64800, 67800, 68800]),
    "colors": [
      "黑色",
      "白色",
      "灰色"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "大車身通勤車款，提供 7230、7250 抽取式鋰電主力規格，可依每日里程選擇容量。",
    "features": [
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "全台到府交車",
      "協助領牌與售後服務"
    ],
    "note": "續航與電池壽命為參考值，實際表現會因載重、路況、環境與使用習慣而異。",
    "images": [
      "/assets/products/davespa/01.webp",
      "/assets/products/davespa/02.webp",
      "/assets/products/davespa/03.webp",
      "/assets/products/davespa/04.webp"
    ]
  },
  {
    "id": "scooter-2",
    "order": 2,
    "name": "小偉士",
    "style": "經典款",
    "visible": true,
    "priceLead": 28000,
    "priceLithium": 45600,
    "colors": [
      "白色",
      "黑色",
      "紅色"
    ],
    "rangeLead": "約 50–55 公里",
    "rangeLithium": "約 60–70 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "車身輕巧、日常通勤取向，可選鉛酸版或鋰鐵 30Ah 可抽取式電池。",
    "features": [
      "鉛酸版／鋰鐵 30Ah 可選",
      "鋰鐵版本可抽取",
      "日常通勤代步",
      "全台到府交車"
    ],
    "note": "續航與電池壽命為參考值，實際表現會因載重、路況、環境與使用習慣而異。",
    "images": [
      "/assets/products/svespa/01.webp",
      "/assets/products/svespa/02.webp",
      "/assets/products/svespa/03.webp"
    ]
  },
  {
    "id": "scooter-3",
    "order": 3,
    "name": "神盾",
    "style": "鋼鐵戰艦版",
    "visible": true,
    "priceLead": 29000,
    "priceLithium": 48000,
    "colors": [
      "白色",
      "黑色",
      "綠色"
    ],
    "rangeLead": "約 50–55 公里",
    "rangeLithium": "約 60–70 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "俐落車身造型，提供鉛酸與鋰鐵 30Ah 可抽取式電池版本。",
    "features": [
      "鉛酸版／鋰鐵 30Ah 可選",
      "鋰鐵版本可抽取",
      "多色可選",
      "完整售後保固服務"
    ],
    "note": "實際車色與配備以當批現車為準；續航與壽命為參考值。",
    "images": [
      "/assets/products/shield/01.webp",
      "/assets/products/shield/02.webp",
      "/assets/products/shield/03.webp",
      "/assets/products/shield/04.webp"
    ]
  },
  {
    "id": "scooter-4",
    "order": 4,
    "name": "天鵝座 Z3",
    "style": "普通版",
    "visible": true,
    "priceLead": 35000,
    "priceLithium": 50800,
    "batteryOptions": yu72BatteryOptions([50800, 59800, 60800, 62800, 63800, 64800, 65800, 68800, 69800]),
    "colors": [
      "白色",
      "黑色",
      "灰色"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "天鵝座 Z3 普通版，提供鉛酸、7230與7250主力規格；長續航版請洽客服。",
    "features": [
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "全台到府交車",
      "協助領牌與售後服務"
    ],
    "note": "實際顏色、配備與交期以客服確認為準。",
    "images": [
      "/assets/products/z3/01.webp",
      "/assets/products/z3/02.webp",
      "/assets/products/z3/03.webp",
      "/assets/products/z3/04.webp"
    ]
  },
  {
    "id": "scooter-5",
    "order": 5,
    "name": "天鵝座 Z3",
    "style": "暗魂版",
    "visible": true,
    "priceLead": 38000,
    "priceLithium": 52800,
    "batteryOptions": yu72BatteryOptions([52800, 61800, 62800, 64800, 65800, 66800, 67800, 70800, 71800]),
    "colors": [
      "消光黑"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "天鵝座 Z3 暗魂版，以深色外觀呈現，可選鉛酸或 7230、7250 抽取式鋰電主力規格。",
    "features": [
      "暗色外觀版本",
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "全台到府交車"
    ],
    "note": "實際配色、配備與交期以客服確認為準。",
    "images": [
      "/assets/products/z3/02.webp",
      "/assets/products/z3/01.webp",
      "/assets/products/z3/03.webp",
      "/assets/products/z3/04.webp"
    ]
  },
  {
    "id": "scooter-6",
    "order": 6,
    "name": "正9號",
    "style": "曠達版",
    "visible": true,
    "priceLead": 35000,
    "priceLithium": 49800,
    "batteryOptions": yu72BatteryOptions([49800, 58800, 59800, 61800, 62800, 63800, 64800, 67800, 68800]),
    "colors": [
      "白色",
      "黑色",
      "其他現車色請洽詢"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "曠達正9號，使用正確曠達版實車照片，可選鉛酸或 7230、7250 抽取式鋰電主力規格。",
    "features": [
      "曠達正9號實車圖",
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "全台到府交車"
    ],
    "note": "實際顏色與配備以現車為準；續航與壽命為參考值。",
    "images": [
      "/assets/products/nine/01.webp",
      "/assets/products/nine/02.webp"
    ]
  },
  {
    "id": "scooter-7",
    "order": 7,
    "name": "正9號",
    "style": "金大力版",
    "visible": true,
    "priceLead": 35000,
    "priceLithium": 49800,
    "batteryOptions": yu72BatteryOptions([49800, 58800, 59800, 61800, 62800, 63800, 64800, 67800, 68800]),
    "colors": [
      "金色",
      "黑色",
      "白色"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "正9號金大力版，可選鉛酸或 7230、7250 抽取式鋰電主力規格。",
    "features": [
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "多色可選",
      "全台到府交車"
    ],
    "note": "金大力版照片與實際配備以現車及客服確認為準。",
    "images": [
      "/assets/products/nine/03.webp",
      "/assets/products/nine/04.webp"
    ]
  },
  {
    "id": "scooter-8",
    "order": 8,
    "name": "小可愛（拿鐵）",
    "style": "可愛馬卡龍版",
    "visible": true,
    "priceLead": 30000,
    "priceLithium": null,
    "colors": [
      "奶茶色",
      "粉色",
      "白色",
      "藍色"
    ],
    "rangeLead": "約 50–55 公里",
    "rangeLithium": "",
    "lifeLead": "約 2 年",
    "lifeLithium": "",
    "description": "小拿鐵為鉛酸版本車款，適合日常代步與通勤。",
    "features": [
      "僅提供鉛酸版本",
      "多色可選",
      "日常通勤代步",
      "全台到府交車"
    ],
    "note": "目前不提供鋰鐵版本；續航與電池壽命為參考值。",
    "images": [
      "/assets/products/latte/01.webp",
      "/assets/products/latte/02.webp",
      "/assets/products/latte/03.webp",
      "/assets/products/latte/04.webp"
    ]
  },
  {
    "id": "scooter-9",
    "order": 9,
    "name": "Dio",
    "style": "經典外型",
    "visible": true,
    "priceLead": 30000,
    "priceLithium": 48000,
    "colors": [
      "白色",
      "黑色"
    ],
    "rangeLead": "請洽客服確認",
    "rangeLithium": "請洽客服確認",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "Dio 經典外型車款，電池版本與續航請依當批現車向客服確認。",
    "features": [
      "鉛酸版／鋰鐵 30Ah 可選",
      "鋰鐵版本可抽取",
      "經典外型",
      "全台到府交車"
    ],
    "note": "Dio 續航尚未由你提供正式區間，因此前台不自行填入數值。",
    "images": [
      "/assets/products/dio/01.webp",
      "/assets/products/dio/02.webp"
    ]
  },
  {
    "id": "scooter-10",
    "order": 10,
    "name": "QC",
    "style": "時尚 QC 款",
    "visible": true,
    "priceLead": 32000,
    "priceLithium": 47800,
    "batteryOptions": yu72BatteryOptions([47800, 56800, 57800, 59800, 60800, 61800, 62800, 65800, 66800]),
    "colors": [
      "白色",
      "黑色",
      "灰色"
    ],
    "rangeLead": "約 60–65 公里",
    "rangeLithium": "約 70–80 公里",
    "lifeLead": "約 2 年",
    "lifeLithium": "約 8–10 年",
    "description": "QC 車款，可選鉛酸版或 7230、7250 抽取式鋰電主力規格。",
    "features": [
      "鉛酸版／7230／7250 可選",
      "7230／7250 可直接選購；長續航請洽客服",
      "多色可選",
      "全台到府交車"
    ],
    "note": "實際顏色及配備以現車為準；續航與壽命為參考值。",
    "images": [
      "/assets/products/qc/01.webp",
      "/assets/products/qc/02.webp"
    ]
  },
  {
    "id": "scooter-11",
    "order": 11,
    "name": "小酷龍",
    "style": "檔車造型款",
    "visible": true,
    "priceLead": 21000,
    "priceLithium": null,
    "colors": [
      "黑色",
      "紅色",
      "藍色"
    ],
    "rangeLead": "請洽客服確認",
    "rangeLithium": "",
    "lifeLead": "約 2 年",
    "lifeLithium": "",
    "description": "小酷龍為鉛酸版本車款，實際續航請依當批車輛向客服確認。",
    "features": [
      "僅提供鉛酸版本",
      "檔車造型",
      "多色可選",
      "售後服務"
    ],
    "note": "目前不提供鋰鐵版本；未提供正式續航區間，不自行填入數值。",
    "images": [
      "/assets/products/dragon/01.webp",
      "/assets/products/dragon/02.webp",
      "/assets/products/dragon/03.webp",
      "/assets/products/dragon/04.webp"
    ]
  },
  {
    "id": "scooter-12",
    "order": 12,
    "name": "微型三輪",
    "style": "載物長者三輪版",
    "visible": true,
    "priceLead": 33000,
    "priceLithium": null,
    "colors": [
      "紅色",
      "藍色",
      "綠色"
    ],
    "rangeLead": "請洽客服確認",
    "rangeLithium": "",
    "lifeLead": "約 2 年",
    "lifeLithium": "",
    "description": "三輪車款，僅提供鉛酸版本。",
    "features": [
      "僅提供鉛酸版本",
      "三輪車身",
      "多色可選",
      "用途請先洽客服確認"
    ],
    "note": "此車款無法領牌，不可作為一般道路合法領牌車使用。",
    "images": [
      "/assets/products/trike/01.webp",
      "/assets/products/trike/02.webp",
      "/assets/products/trike/03.webp",
      "/assets/products/trike/04.webp"
    ]
  }
];
