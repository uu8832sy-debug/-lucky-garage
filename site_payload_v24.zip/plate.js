import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import { doc, getFirestore, serverTimestamp, setDoc } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

const firebaseConfig = window.LUCKY_GARAGE_FIREBASE_CONFIG || {};
const config = window.YU_STORE_CONFIG || {};
const db = getFirestore(initializeApp(firebaseConfig));
const $ = (selector) => document.querySelector(selector);
const money = (value) => `NT$${Math.max(0, Number(value) || 0).toLocaleString("zh-TW")}`;
let captcha = 0;

function cleanPhone(value) {
  let digits = String(value || "").replace(/\D/g, "");
  if (digits.startsWith("886")) digits = `0${digits.slice(3)}`;
  return digits;
}
function makeId() {
  const date = new Date();
  const ymd = `${date.getFullYear()}${String(date.getMonth()+1).padStart(2,"0")}${String(date.getDate()).padStart(2,"0")}`;
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint32Array(4);
  crypto.getRandomValues(bytes);
  return `PLATE-${ymd}-${[...bytes].map(value => chars[value % chars.length]).join("")}`;
}
function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove("show"), 3200);
}
function showOrderSuccess(orderId) {
  const screen = $("#orderSuccessScreen");
  if (!screen) return;
  $("#orderSuccessTitle").textContent = "訂製需求已建立";
  $("#orderSuccessText").textContent = "資料已送進小宇微電訂單系統，正在開啟官方 LINE，請把剛剛複製的訂製資訊傳給客服確認。";
  $("#orderSuccessId").textContent = orderId;
  $("#orderSuccessLine").href = config.lineUrl || "https://line.me/R/ti/p/@762eqvlg";
  screen.classList.add("show");
  screen.setAttribute("aria-hidden", "false");
}
function newCaptcha() {
  const a = Math.floor(Math.random()*8)+2;
  const b = Math.floor(Math.random()*8)+2;
  captcha = a+b;
  $("#captchaQuestion").textContent = `人類驗證：${a} + ${b} = ?`;
  $("#captchaAnswer").value = "";
}

const price = Number(config.platePrice || 9500);
const deposit = Number(config.plateDeposit || 5500);
const balance = Number(config.plateBalance || 4000);
$("#priceText").textContent = money(price);
$("#depositText").textContent = money(deposit);
$("#balanceText").textContent = money(balance);

$("#plateNumber").addEventListener("input", () => {
  const value = $("#plateNumber").value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0,12);
  $("#plateNumber").value = value;
  $("#platePreview").textContent = value || "ABC-1234";
});

$("#plateForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if ($("#website").value) return;
  if (Number($("#captchaAnswer").value) !== captcha) { newCaptcha(); toast("驗證答案錯誤，請重新計算。"); return; }

  const customerName = $("#name").value.trim();
  const phone = cleanPhone($("#phone").value);
  const address = $("#address").value.trim();
  const plateNumber = $("#plateNumber").value.trim().toUpperCase();
  const plateType = $("#plateType").value;
  if (!customerName || phone.length < 9 || address.length < 3 || !plateNumber) { toast("請完整填寫訂製資料。"); return; }

  const orderId = makeId();
  const data = {
    orderNo:orderId, orderId, source:"official-store-plate", customerName, custName:customerName, phone, custPhone:phone, address, custAddress:address,
    model:"紀念展示車牌", itemName:`${plateType}｜${plateNumber}`, color:"依訂製樣式", vehicleVariant:plateType, battery:"不適用", price, totalAmount:money(price),
    cost:0, netProfit:price, deposit:0, balancePaid:0, licenseMode:"自行辦理", deliveryMode:"物流寄送", paymentMethod:"轉帳",
    paymentTerms:`訂金 ${money(deposit)}／尾款 ${money(balance)}（貨到付款）`, status:"待訂金", deliveredAt:"",
    notes:`訂製號碼：${plateNumber}。僅供紀念展示，不可上路使用。`, createdAt:serverTimestamp(), updatedAt:serverTimestamp(), timestamp:serverTimestamp(), createdBy:"public-store", updatedBy:"public-store"
  };

  const button = $("#submitBtn");
  button.disabled = true;
  button.textContent = "送出中…";
  try {
    await setDoc(doc(db, "orders", orderId), data);
    const message = `您好小宇，我要訂製紀念展示牌：\n訂單編號：${orderId}\n類型：${plateType}\n號碼：${plateNumber}\n姓名：${customerName}\n電話：${phone}\n收件資料：${address}\n付款方式：訂金 ${money(deposit)}／尾款 ${money(balance)}（貨到付款）\n請協助確認付款。`;
    try { await navigator.clipboard.writeText(message); } catch {}
    toast(`訂製需求 ${orderId} 已建立。`);
    showOrderSuccess(orderId);
    setTimeout(() => { window.location.href = config.lineUrl || "https://line.me/R/ti/p/@762eqvlg"; }, 1500);
    event.target.reset();
    $("#plateNumber").value = "ABC-1234";
    $("#platePreview").textContent = "ABC-1234";
    newCaptcha();
  } catch (error) {
    console.error(error);
    toast("送出失敗，請直接聯絡官方 LINE。");
  } finally {
    button.disabled = false;
    button.textContent = "送出訂製需求並開啟 LINE";
  }
});

newCaptcha();
